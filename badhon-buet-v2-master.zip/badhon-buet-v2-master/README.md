# Badhan BUET Zone Website Version 2.0
This is a collaborative endevour to develop a website for Badhan BUET zone.
This project will take advantage of latest techniques to make the development, testing and deployment process seemless.


# How to run?
First, you need to build the image
```
sudo docker build -t badhan:latest .
```

Then run the container
```
sudo docker run -i -t -p 5000:5000 badhan 

instead of sudo docker run -p 5000:5000 badhan , then ctrl + C will stop the container and to run container in the background and also to free the terminal at the same time use ctrl P+Q

if I add -d in the line above the process starts detached but then we need to stop the container manually .
```

this worked for me :)

but I couldn't make the server and client app run simultaneously with runner.sh or Dockerfile :(
